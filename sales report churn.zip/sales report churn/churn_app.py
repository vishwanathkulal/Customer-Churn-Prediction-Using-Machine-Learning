import streamlit as st
import pandas as pd
import joblib

# Load trained model and feature names
model = joblib.load("churn_model.pkl")
feature_names = joblib.load("feature_names.pkl")

st.set_page_config(page_title="Customer Churn Prediction", layout="centered")
st.title("Customer Churn Prediction App")
st.write("This tool helps you predict whether a customer is likely to churn based on basic service details.")

# Sidebar for user input
st.sidebar.header("Customer Information")

def user_input():
    gender = st.sidebar.selectbox("Gender", ["Male", "Female"])
    senior = st.sidebar.selectbox("Senior Citizen", [0, 1])
    tenure = st.sidebar.slider("Tenure (in months)", 0, 72, 12)
    monthly = st.sidebar.slider("Monthly Charges", 0.0, 150.0, 70.0)
    total = st.sidebar.number_input("Total Charges", min_value=0.0, value=1000.0)

    data = {
        'gender': 1 if gender == "Male" else 0,
        'SeniorCitizen': senior,
        'tenure': tenure,
        'MonthlyCharges': monthly,
        'TotalCharges': total
    }

    return pd.DataFrame([data])

# Collect input
input_df = user_input()
input_df = input_df[feature_names]

# Display input
st.subheader("Customer Profile")
st.dataframe(input_df)

# Prediction button
if st.button("Predict Churn"):
    prediction = model.predict(input_df)[0]
    probability = model.predict_proba(input_df)[0][1] * 100

    if prediction == 1:
        st.error("This customer is likely to churn.")
        st.write(f"Estimated risk of churn: {probability:.2f}%")
        st.write("Suggestion: Consider offering a discount or personalized support to retain the customer.")
    else:
        st.success("This customer is likely to stay.")
        st.write(f"Estimated likelihood of retention: {100 - probability:.2f}%")
        st.write("Suggestion: You may consider promoting loyalty benefits or upselling new features.")

    st.markdown("---")
    st.write("Use this prediction to take proactive actions and reduce customer loss.")
