import streamlit as st
import pandas as pd
import joblib
import xgboost as xgb

# Load model and feature names
model = joblib.load("churn_model_advanced.pkl")
feature_names = joblib.load("features_names.pkl")

st.title("Customer Churn Prediction (Advanced Model)")

st.sidebar.header("Enter Customer Information")

# Function to collect user input
def user_input():
    data = {
        'gender': st.sidebar.selectbox("Gender", ["Male", "Female"]),
        'SeniorCitizen': st.sidebar.selectbox("Senior Citizen", [0, 1]),
        'Partner': st.sidebar.selectbox("Partner", ["Yes", "No"]),
        'Dependents': st.sidebar.selectbox("Dependents", ["Yes", "No"]),
        'tenure': st.sidebar.slider("Tenure (months)", 0, 72, 12),
        'PhoneService': st.sidebar.selectbox("Phone Service", ["Yes", "No"]),
        'MultipleLines': st.sidebar.selectbox("Multiple Lines", ["Yes", "No", "No phone service"]),
        'InternetService': st.sidebar.selectbox("Internet Service", ["DSL", "Fiber optic", "No"]),
        'OnlineSecurity': st.sidebar.selectbox("Online Security", ["Yes", "No", "No internet service"]),
        'OnlineBackup': st.sidebar.selectbox("Online Backup", ["Yes", "No", "No internet service"]),
        'DeviceProtection': st.sidebar.selectbox("Device Protection", ["Yes", "No", "No internet service"]),
        'TechSupport': st.sidebar.selectbox("Tech Support", ["Yes", "No", "No internet service"]),
        'StreamingTV': st.sidebar.selectbox("Streaming TV", ["Yes", "No", "No internet service"]),
        'StreamingMovies': st.sidebar.selectbox("Streaming Movies", ["Yes", "No", "No internet service"]),
        'Contract': st.sidebar.selectbox("Contract", ["Month-to-month", "One year", "Two year"]),
        'PaperlessBilling': st.sidebar.selectbox("Paperless Billing", ["Yes", "No"]),
        'PaymentMethod': st.sidebar.selectbox("Payment Method", [
            "Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"
        ]),
        'MonthlyCharges': st.sidebar.slider("Monthly Charges", 0.0, 150.0, 70.0),
        'TotalCharges': st.sidebar.number_input("Total Charges", 0.0, 1000.0)
    }
    return pd.DataFrame([data])

# Get user input
input_df = user_input()

# One-hot encode input
input_encoded = pd.get_dummies(input_df)

# Add any missing columns that model expects
for col in feature_names:
    if col not in input_encoded.columns:
        input_encoded[col] = 0

# Reorder columns to match training
input_encoded = input_encoded[feature_names]

st.subheader("Customer Information Preview")
st.write(input_encoded)

# Predict button
if st.button("Predict Churn"):
    prediction = model.predict(input_encoded)[0]
    result = "Likely to Churn" if prediction == 1 else "Not Likely to Churn"
    st.success(f"Prediction: {result}")
